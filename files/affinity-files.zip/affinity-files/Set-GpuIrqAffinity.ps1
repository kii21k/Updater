﻿<#
.SYNOPSIS
    Apply or revert GPU IRQ-affinity.

.PARAMETER Core
    Core list/range e.g. "4-5", "2,4,8-11", 0..11  (quote dash-ranges!).

.PARAMETER Mask
    Explicit 64-bit affinity mask (hex or decimal).

.PARAMETER Revert
    Remove the entire “Affinity Policy” key – GPU goes back to using all CPUs.

.PARAMETER Restart
    After changes, auto-restart each GPU with DevCon.exe if it’s available.

.NOTES
    Run from an elevated PowerShell prompt, then reboot (or use -Restart).
#>

param(
    [string]  $Core,
    [UInt64]  $Mask,
    [switch]  $Revert,
    [switch]  $Restart
)

function Expand-CoreSpec ($spec) {
    # Accept an array (0..11) or a string ("4-5,8")
    if ($spec -is [array]) { $spec = ($spec -join ',') }

    $list = foreach ($part in ($spec -split ',')) {
        switch -Regex ($part.Trim()) {
            '^\d+$'              { [int]$_ ; break }                     # single #
            '^\d+\s*-\s*\d+$'    {                                        # dash range
                $a,$b = ($_ -split '-') | ForEach-Object { [int]$_ }
                if ($b -lt $a) { throw "Range '$part' is backwards." }
                $a..$b ; break
            }
            '^\d+\s*\.\.\s*\d+$' {                                        # dot-dot range
                $a,$b = ($_ -split '\.\.') | ForEach-Object { [int]$_ }
                if ($b -lt $a) { throw "Range '$part' is backwards." }
                $a..$b ; break
            }
            default { throw "Bad core spec '$part'." }
        }
    }
    return $list | Sort-Object -Unique
}

# ─── enumerate active GPUs ──────────────────────────────────────────────
$gpus = Get-PnpDevice -Class Display | Where-Object Status -eq 'OK'
if (-not $gpus) { throw "No active GPU devices found." }

# ─── REVERT branch ──────────────────────────────────────────────────────
if ($Revert) {

    if ($Core -or $Mask) { throw "-Revert cannot be combined with -Core/-Mask." }

    foreach ($gpu in $gpus) {
        $affKey = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($gpu.InstanceId)\Device Parameters\Interrupt Management\Affinity Policy"
        if (Test-Path $affKey) {
            Remove-Item -Path $affKey -Recurse -Force
            Write-Host "Cleared affinity on $($gpu.FriendlyName)"
        } else {
            Write-Host "No custom affinity on $($gpu.FriendlyName) — skipped"
        }
    }

} else {

    # ─── build KAFFINITY mask ───────────────────────────────────────────
    if ($Mask -and $Core) { throw "Use either -Core or -Mask, not both." }
    if (-not $Mask) {
        if (-not $Core) { throw "Supply -Core or -Mask." }
        $Mask = 0
        foreach ($c in Expand-CoreSpec $Core) {
            if ($c -notin 0..63) { throw "Core $c out of range 0-63." }
            $Mask = $Mask -bor ([UInt64]1 -shl $c)   # cast literal for PS 5.x
        }
    }
    Write-Host ("Using affinity mask 0x{0:X16}`n" -f $Mask)
    $maskBytes = [BitConverter]::GetBytes($Mask)

    # ─── write policy ──────────────────────────────────────────────────
    foreach ($gpu in $gpus) {
        $reg = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($gpu.InstanceId)\Device Parameters\Interrupt Management\Affinity Policy"
        if (-not (Test-Path $reg)) { New-Item $reg -Force | Out-Null }

        if (Test-Path "$reg\AssignmentSetOverride") {
            Remove-ItemProperty -Path $reg -Name AssignmentSetOverride -Force
        }

        New-ItemProperty -Path $reg -Name DevicePolicy          -PropertyType DWord  -Value 4         -Force | Out-Null
        New-ItemProperty -Path $reg -Name AssignmentSetOverride -PropertyType Binary -Value $maskBytes -Force | Out-Null

        Write-Host "Policy written on $($gpu.FriendlyName)"
    }
}

# ─── restart device(s) or remind user ──────────────────────────────────
if ($Restart) {
    if (Get-Command devcon -ErrorAction Ignore) {
        foreach ($gpu in $gpus) { devcon restart "$($gpu.InstanceId)" 2>$null }
        Write-Host "`nDevice(s) restarted."
    } else {
        Write-Host "`n-Restart requested, but DevCon.exe not found."
    }
} else {
    Write-Host "`nReboot or disable/enable the GPU to activate the change."
}
